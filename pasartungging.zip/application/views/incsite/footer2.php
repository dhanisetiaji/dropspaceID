<script src="<?php echo base_url(); ?>assets/site/js/jquery.js"></script>
	<script src="<?php echo base_url(); ?>assets/site/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/site/js/jquery.scrollUp.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/site/js/price-range.js"></script>
    <script src="<?php echo base_url(); ?>assets/site/js/jquery.prettyPhoto.js"></script>
    <script src="<?php echo base_url(); ?>assets/site/js/main.js"></script>