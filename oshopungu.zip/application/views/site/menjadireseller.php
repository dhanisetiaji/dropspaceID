<!DOCTYPE html>
<html lang="en">
<head>
    <?php $this->load->view('incsite/head'); ?>
</head><!--/head-->

<body>
	<?php $this->load->view('incsite/head2'); ?>
	
	<section>
		<div class="container">
					<style type="text/css">
							.bannernya{
								position: relative;
							}
					</style>
				<div class="bannernya" style="position:relative;">
					<img class="img-responsive" src="https://www.lemoncustomshop.com/image/cache/RESELLER/landpage%201-1096x630.jpg" alt="">
					<img class="img-responsive" src="https://www.lemoncustomshop.com/image/cache/RESELLER/yang%20jelas%20profitnya%20222-1096x523.jpg" alt="">
					<img class="img-responsive" src="https://www.lemoncustomshop.com/image/cache/RESELLER/keuntungan%20per%20produk-1096x630.jpg" alt="">
					<img class="img-responsive" src="https://www.lemoncustomshop.com/image/cache/RESELLER/landpage%204%20newwww-1096x969.jpg" alt="">
					<img class="img-responsive" src="https://www.lemoncustomshop.com/image/cache/RESELLER/landpage%205-1096x969.jpg" alt="">
					<img class="img-responsive" src="https://www.lemoncustomshop.com/image/cache/RESELLER/landpage%207-1096x523.jpg" alt="">
					<!-- <center><a href="https://api.whatsapp.com/send?phone=628122727051&text=Hallo ka,%20saya%20mau%20join%20reseller%20<?php echo base_url(); ?>."><button type="button" class="btn btn-primary btn-lg">KLIK DISINI UNTUK JOIN RESELLER</button></a></center><br> -->
					<center><button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#cskntk">KLIK DISINI UNTUK JOIN RESELLER</button></a></center><br>
										<!-- Modal -->
					<div class="modal fade" id="cskntk" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
					<div class="modal-dialog" role="document">
						<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title" id="exampleModalLabel">SILAHKAN PILIH ADMIN DIBAWAH INI :</h5>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
							</button>
						</div>
						<div class="modal-body">
										<center><a href="https://api.whatsapp.com/send?phone=628122727051&text=Hallo ka,%20saya%20mau%20join%20reseller%20<?php echo base_url(); ?>."><button type="button" class="btn btn-primary btn-lg">ADMIN 1</button></a>   <a href="https://api.whatsapp.com/send?phone=628122727051&text=Hallo ka,%20saya%20mau%20join%20reseller%20<?php echo base_url(); ?>."><button type="button" class="btn btn-primary btn-lg">ADMIN 2</button></a></center>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
						</div>
						</div>
					</div>
					</div>
					<div data-type="countdown" data-id="1374260" class="tickcounter" style="width: 100%; position: relative; padding-bottom: 25%"><a href="//www.tickcounter.com/countdown/1374260/hanya-untuk-100-tercepat" title="hanya untuk 100 tercepat">hanya untuk 100 tercepat</a><a href="//www.tickcounter.com/" title="Countdown">Countdown</a></div><script>(function(d, s, id) { var js, pjs = d.getElementsByTagName(s)[0]; if (d.getElementById(id)) return; js = d.createElement(s); js.id = id; js.src = "//www.tickcounter.com/static/js/loader.js"; pjs.parentNode.insertBefore(js, pjs); }(document, "script", "tickcounter-sdk"));</script>
					
					<img class="img-responsive" src="https://www.lemoncustomshop.com/image/cache/RESELLER/mapan-1096x523.jpg" alt="">
				</div>
		</div>
	</section>
	<footer id="footer"><!--Footer-->		
		<div class="footer-bottom">
			<div class="container">
				<div class="row">
					<p class="pull-left">Copyright © 2019.</p>
					<p class="pull-right">Powered by <span>dhani setiaji</span></p>
				</div>
			</div>
		</div>
		
	</footer><!--/Footer-->
	<?php $this->load->view('incsite/footer2'); ?>
</body>
</html>