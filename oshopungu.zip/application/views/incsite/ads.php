<div class="shipping text-center"><!--shipping-->
		<img src="<?php echo base_url(); ?>assets/site/images/home/shipping.jpg" alt="" /><br><br>
	</div><!--/shipping-->