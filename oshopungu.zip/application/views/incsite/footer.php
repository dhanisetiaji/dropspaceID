<footer id="footer"><!--Footer-->		
		<div class="footer-widget">
			<div id="kontak">
			<div class="container">
				<div class="row">
					<div class="col-sm-3 col-sm-offset-1">
						<div class="double-widget">
							<h3>TENTANG KAMI </h3><br>
							<p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Doloremque sunt expedita nihil facere commodi voluptate, eligendi quaerat fugiat architecto fuga numquam veniam adipisci dolor sapiente! Minus quis possimus est laudantium.</p>
						</div>
					</div>
					<div class="col-sm-3 col-sm-offset-1">
						<div class="double-widget">
							<h3>LAYANAN PELANGGAN</h3><br>
							<p>call only 087726269859</p>
							<p>Mon - Sat (08.00 - 17.00)</p>
							<p>Jalan begudul blok 5b no 10, RT.8/RW.11, Kalideres, Kec. Kalideres, Kota Jakarta Barat, Daerah Khusus Ibukota Jakarta 11840</p>
						</div>
					</div>

					<div class="col-sm-3 col-sm-offset-1">
						<div class="double-widget">
							<h3>Follow Us </h3><br>
							<p>Follow kami di media sosial</p>
							<p>
								<a href="#"><i class="fa fa-facebook"></i></a>
								<a href="https://instagram.com/dropspace.id"><i class="fa fa-instagram"></i></a>
								<a href="#"><i class="fa fa-google-plus"></i></a>
							</p>
						</div>
					</div>
					
				</div>
			</div>
			</div>
		</div>
		
		<div class="footer-bottom">
			<div class="container">
				<div class="row">
					<p class="pull-left">Copyright © 2019</p>
					<p class="pull-right">Powered by <span><a href="https://instagram.com/dhanisetiaji_">Dhani Setiaji</a></span></p>
				</div>
			</div>
		</div>
		
	</footer><!--/Footer-->