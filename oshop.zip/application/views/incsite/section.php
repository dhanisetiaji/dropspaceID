<div class="col-sm-9 padding-right">
    <style type="text/css">
		.buttonnya{
		position: absolute;
		top: 10;
		bottom: 40px;
		right: 100px;
		}
		.bannernya{
		position: relative;;
		}
        </style>					
		<div class="bannernya" style="position:relative;">
		<a href="<?php echo base_url(); ?>site/menjadireseller"><img class="img-responsive" src="https://www.lemoncustomshop.com/image/cache/RESELLER/banner%20home%20reseller-1096x404.jpg">
		<!-- <div class="buttonnya" >
			<a href="#"><button>Join Now</button></a>
		</div> --></a>
	    </div>
</div>